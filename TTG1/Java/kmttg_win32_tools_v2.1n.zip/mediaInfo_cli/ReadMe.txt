MediaInfo - http://mediainfo.sourceforge.net
Copyright (c) 2002-2010 MediaArea.net SARL, Info@MediaArea.net

License
-------
This program is freeware (LGLPv2+).
See License.html for more information.


Usage
-----
mediainfo FileName
mediainfo --Help
